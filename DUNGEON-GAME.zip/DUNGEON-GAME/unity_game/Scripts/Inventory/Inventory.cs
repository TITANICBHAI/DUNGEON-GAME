using System.Collections.Generic;

[System.Serializable]
public class Inventory
{
    public List<Item> items = new List<Item>();
}
